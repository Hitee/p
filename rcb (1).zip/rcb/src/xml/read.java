package xml;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;

public class read {
	public static void main(String[] args) 
    { 
        try { 
            FileInputStream file = new FileInputStream(new File("C:/Users/hisachde/Desktop/Test.xls")); 
  
            // Create Workbook instance holding reference to .xls file 
            HSSFWorkbook workbook = new HSSFWorkbook(file); 
  
            // Get first/desired sheet from the workbook 
            HSSFSheet sheet = workbook.getSheetAt(0); 
  
            // Iterate through each rows one by one 
            Iterator<Row> rowIterator = sheet.iterator(); 
            while (rowIterator.hasNext()) { 
                Row row = rowIterator.next(); 
                // For each row, iterate through all the columns 
                Iterator<Cell> cellIterator = row.cellIterator(); 
  
                while (cellIterator.hasNext()) { 
                    Cell cell = cellIterator.next(); 
                    // Check the cell type and format accordingly 
                    switch (cell.getCellType()) { 
//                    case Cell.CELL_TYPE_NUMERIC: 
//                        System.out.print(cell.getNumericCellValue() + "\t"); 
//                        break; 
                    case Cell.CELL_TYPE_STRING: 
                    	//System.out.print(cell.getStringCellValue() + "\t"); 
						/*
						 * if(cell.getStringCellValue().equalsIgnoreCase("a")) {
						 * System.out.println("hi"); System.out.print(cell.getStringCellValue() + "\t");
						 * System.out.println(rowIterator.hasNext()); int index = cell.getRowIndex();
						 * System.out.println("index " + cell.getRowIndex());
						 * 
						 * // while (rowIterator.hasNext()) // { // System.out.println(); // } }
						 */
                        for (Row row1 : sheet) { // For each Row.
                        	if(cell.getStringCellValue().equalsIgnoreCase("a"))
                        	{
                            Cell cell1 = row1.getCell(0); // Get the Cell at the Index / Column you want.
                            System.out.println("cell1 " + cell1);
                        	}
                            
                        }
                        break; 
                    } 
                } 
                System.out.println(""); 
            } 
            file.close(); 
        } 
        catch (Exception e) { 
            e.printStackTrace(); 
        } 
    } 
}
