package rbc1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.json.JSONObject;
public class TESTING2 {

	public static void main(String[] args) throws IOException {
		
		Workbook wb = new HSSFWorkbook();

		FileOutputStream fileOut = new FileOutputStream("C:/Users/hisachde/Desktop/Test.xls");

	



		CreationHelper createHelper = wb.getCreationHelper();

		org.apache.poi.ss.usermodel.Sheet sheet = wb

				.createSheet("Sheet1");
		
		
		
		 Row row1 = sheet.createRow((short) 0);
		//wb.write(fileOut);
	//	fileOut.close(); ///add somewhere figure out
		
		String[] myArray= new String[5];
		
		try { 


//"http://api.ipinfodb.com/v3/ip-city/?key=d64fcfdfacc213c7ddf4ef911dfe97b55e4696be3532bf8302876c09ebd06b&ip=74.125.45.100&format=json"
			String url = "http://maps.googleapis.com/maps/api/geocode/json?address=chicago&sensor=false&#8221";
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection)obj.openConnection();
			//HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			// optional default is GET
			con.setRequestMethod("GET");
			con.connect();
			//Get the response status of the Rest API
			int responsecode = con.getResponseCode();
			System.out.println("Response code is: " +responsecode);
			//add request header
			//con.setRequestProperty("User-Agent", "Mozilla/5.0");
			int responseCode = con.getResponseCode();
			System.out.println("\nSending 'GET' request to URL : " + url);
			// System.out.println("Response Code : " + responseCode);


			if(responseCode != 200)
				throw new RuntimeException();
			else
			{
				Scanner sc = new Scanner(obj.openStream());
				String inline = null;
				while(sc.hasNext())
				{
					inline+=sc.nextLine();
				}
				System.out.println("\nJSON data in string format");
				//System.out.println(inline);
				sc.close();
			}



			BufferedReader in = new BufferedReader(
					new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			//print in String
			//  System.out.println(response.toString());
			//Read JSON response and print
			JSONObject myResponse = new JSONObject(response.toString());
			System.out.println("result after Reading JSON Response");
			System.out.println(myResponse.length());
			
			//Row row1 = sheet.createRow((short) 0);
			for(int i=0 ; i<1 ; i++)
			{
			//	Scanner myObj = new Scanner(System.in);  // Create a Scanner object
				//  System.out.println("Enter data " + i);

				// String data = myObj.nextLine();  // Read user input
				// System.out.println("data " + i + " is: " + data);  // Output user input 
				//myResponse.
				System.out.println("error_message- "+myResponse.getString("error_message").codePointCount(0, 20));
				
				myArray[i] = myResponse.getString("error_message");
				System.out.println("hi " + myArray[i]);
				 row1.createCell(0).setCellValue(
						  
						  createHelper.createRichTextString(myArray[i]));
				
				 wb.write(fileOut);  


			} 
			//row1.createCell(1).setCellValue(createHelper.createRichTextString("hi")); wb.write(fileOut); 
					 wb.write(fileOut);  
					 //fileOut.close();

			/*
			 * System.out.println("statusMessage- "+myResponse.getString("statusMessage"));
			 * System.out.println("ipAddress- "+myResponse.getString("ipAddress"));
			 * System.out.println("countryCode- "+myResponse.getString("countryCode"));
			 * System.out.println("countryName- "+myResponse.getString("countryName"));
			 * System.out.println("regionName- "+myResponse.getString("regionName"));
			 * System.out.println("cityName- "+myResponse.getString("cityName"));
			 * System.out.println("zipCode- "+myResponse.getString("zipCode"));
			 * System.out.println("latitude- "+myResponse.getString("latitude"));
			 * System.out.println("longitude- "+myResponse.getString("longitude"));
			 * System.out.println("timeZone- "+myResponse.getString("timeZone"));
			 */
		} catch (Exception e) {
			//System.out.println("hi");
			e.printStackTrace();
		}
	}
	/*
	 * public static void call_me() throws Exception {
	 * 
	 * }
	 */
}