package com.capg.cms.dao;
import java.util.HashMap;
import java.util.Map;

import com.capg.cms.beans.Customer;
import com.capg.cms.expection.CustomerNotFound;
public class CustomerDAOImp implements ICustomerDAO {
StringBuffer sb = new StringBuffer();
	//for database use collections
	//public static List<Customer> custList = new ArrayList<Customer>();
	//CustomerDAOImp dao = new CustomerDAOImp();
	Map<Long, Customer> custList = new HashMap<Long, Customer>();
	Map<Long, StringBuffer> transaction = new HashMap<Long, StringBuffer>();
	//custList.put(1,bean);
	
	@Override
	public boolean addCustomer(long accNo, Customer c) 
	{
		// TODO Auto-generated method stub
		
		boolean isAdded = false;
	
		// add - predefined method of collections, returns boolean value
		custList.put(accNo,c);
		//System.out.println("this is custlist" + custList);
		
		return isAdded;
	
	
	}

	//@Override
	public Customer displayCustomer(long accountNo , int pin) 
	{
		// TODO Auto-generated method stub
		//System.out.println("gertr");
		Customer cust = null;
		for (Customer custList1 : custList.values() ) 
		{
		if(custList1.getAccountNo() == accountNo && custList1.getPin() == pin)
		{
			cust = custList1;
			//System.out.println("inside ");
			// System.out.println("Value = " + custList1.getBalance());
		}
		else System.out.println("no customer !");
		   
		}
		
		return cust;
	}
	
	
	
	public Customer deposit(long accountNo , double depositAmount) throws CustomerNotFound 
	{
		// TODO Auto-generated method stub
		
		Customer cust = null;
		
		for (Customer custList1 : custList.values()) 
		{
		if(custList1.getAccountNo() == accountNo)
		{
			 //System.out.println("Value = " + custList.getBalance());
			//transaction.put(custList1.getAccountNo() , sb.append("deposited amount " + depositAmount));
		}
		   
		}
		
	
		//
		for(Customer custList : custList.values())
		{
			if(custList.getAccountNo() == accountNo)
				
		
			{
				
				double amt = custList.getBalance();
				
				
				amt = amt + depositAmount;
				custList.setBalance(amt);
				
				System.out.println(".......");
				System.out.println(transaction);
				
				cust = custList;
			}
		}
		
		
		return cust;
	}
	
	
	
	public Customer withdraw(long accountNo , int pin , double withdrawAmount, StringBuffer sb) 
	{
		// TODO Auto-generated method stub
		
		Customer cust = null;
		
		for (Customer custList : custList.values()) 
		{
		if(custList.getAccountNo() == accountNo)
			{
				double amt = custList.getBalance();
				if(withdrawAmount < amt)
				{
					amt = amt - withdrawAmount;
					
					custList.setBalance(amt);
					cust = custList;
					
					
					
				}
				
			}
		}
		
		return cust;
		
	}
	
	
	public Customer fundTransfer(long accountNo , int pin, long accountNoTransfer , double amountTransfer, StringBuffer sb, StringBuffer sbT)
	{
		Customer cust = null;
		
		for (Customer custList1 : custList.values()) 
		{
			//Customer tr = new Customer();
		if(custList1.getAccountNo() == accountNo && custList1.getPin() == pin /*&& tr.getAccountNo()== accountNoTransfer*/)
		
			{
				double amt = custList1.getBalance();
				if(amountTransfer < amt)
				{
					double from = custList1.getBalance();
					from = from - amountTransfer;
					
					for (Customer custList2 : custList.values()) 
					{
					if(custList.containsKey(accountNoTransfer) && custList.containsKey(accountNo))
					{
						double to = custList2.getBalance();
						to = to + amountTransfer;
						custList2.setBalance(to);
						custList1.setBalance(from);
						cust = custList2;
						//System.out.println(custList2.getBalance() + "vdf");
						
					}
					else 
					{
						System.out.println("sssssssss");
					}
				}
					
				
				
			}
		}
		}
		//CustomerDAOImp dao = new CustomerDAOImp();
		//dao.printTransactions(custList1);
		return cust;
	}
	
	public Customer printTransactions(Customer ac)
	{
		Customer cust = null;
		long a = ac.getAccountNo();
		StringBuffer s = new StringBuffer();
		s = ac.getSb();
		s.append("balance is now ");
		s.append(ac.getBalance());
		ac.setSb(s);
		transaction.put(a, s);
		System.out.println("inside print transaction");
		for(StringBuffer transaction1 : transaction.values())
		{
			
			transaction.entrySet().stream().forEach(System.out::println);
			System.out.println("aaaaaaa");
			System.out.println(transaction);
		}
		return cust;
	}

	@Override
	public Customer printTrns(long ac) {
		// TODO Auto-generated method stub
		/*Customer cust = null;
		for (long trns : transaction.keySet()Customer custList1 : custList.values() ) 
		{
		if(custList1.getAccountNo() == accountNo && custList1.getPin() == pin)
		{
			cust = custList1;
			//System.out.println("inside ");
			// System.out.println("Value = " + custList1.getBalance());
		}
		else System.out.println("nnnnnnn");
		   
		}
		
		return cust;*/
		
		
		/*for(StringBuffer trns : transaction.values())
		{
			if(transaction.containsKey(ac))
			{
				System.out.println("inside print transaction " + transaction.values());
				//transaction.entrySet().stream().forEach(System.out::println);
			}
		}*/
		if (transaction.containsKey(ac)) {
			   Object value = transaction.get(ac);
			 System.out.println("Account number : " + ac +"\n"+ value + "\n");
			 }
		return null;
	}
	
	
	
	

}
