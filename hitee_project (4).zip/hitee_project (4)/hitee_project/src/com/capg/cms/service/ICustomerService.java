package com.capg.cms.service;

import com.capg.cms.beans.Customer;
import com.capg.cms.expection.CustomerNotFound;

//import com.capg.cms.dao.CustomerNotFound;

public interface ICustomerService {
	
	
	
	//public boolean addCustomer(Customer c);
	public Customer displayCustomer(int cid);
	boolean addCustomer(long accNo, Customer c);
	public Customer printTransactions(Customer c);
	public Customer deposit(long accountNo, double depositAmount) throws CustomerNotFound;
	public Customer withdraw(long accountNo, int pin , double withdrawAmount, StringBuffer sb);
	public Customer printTrns(long accNo);
	

}
