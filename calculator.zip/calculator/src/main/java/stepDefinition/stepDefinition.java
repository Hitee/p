package stepDefinition;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class stepDefinition {

	private FormPageFactory fact;
	private WebDriver driver;

	@Given("^check user name_null$")
	public void check_user_name_null() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		fact = new FormPageFactory(driver);
		driver.get("file:///C:/Users/hisachde/Desktop/Basicform.html");
	}

	@When("^enter null user name text box$")
	public void enter_null_user_name_text_box() throws Throwable {
	    fact.setUserName("");
	    fact.setButton();
	    
	}

	@Then("^print error message for name field$")
	public void print_error_message_for_name_field() throws Throwable {
	    System.out.println("null value for name ");
	    String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		//driver.close();
	}
	
	
	
	

	@Given("^check user name_true$")
	public void check_user_name_true() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		fact = new FormPageFactory(driver);
		driver.get("file:///C:/Users/hisachde/Desktop/Basicform.html");
	}

	@When("^enter true value in user name text box$")
	public void enter_true_value_in_user_name_text_box() throws Throwable {
		fact.setUserName("56356");
	    fact.setButton();
	    }

	@Then("^print correct name$")
	public void print_correct_name() throws Throwable {
		 System.out.println("checking for correct name ");
		    String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			//driver.close();
	}

	@Given("^check user name_false$")
	public void check_user_name_false() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^enter wrong user name text box$")
	public void enter_wrong_user_name_text_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^print wrong name$")
	public void print_wrong_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


	
	
	/////////////////////////////////////
	
	
	@Given("^check  city_null$")
	public void check_city_null() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		fact = new FormPageFactory(driver);
		driver.get("file:///C:/Users/hisachde/Desktop/Basicform.html");
	}

	@When("^enter null city text box$")
	public void enter_null_city_text_box() throws Throwable {
		 fact.setCity("");
		    fact.setButton();
	}

	@Then("^print error message for city field$")
	public void print_error_message_for_city_field() throws Throwable {
		System.out.println("null value for city");
	    String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		//driver.close();
	}

	@Given("^check password_null$")
	public void check_password_null() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		fact = new FormPageFactory(driver);
		driver.get("file:///C:/Users/hisachde/Desktop/Basicform.html");
	}

	@When("^enter null password text box$")
	public void enter_null_password_text_box() throws Throwable {
		 fact.setPassword("");
		    fact.setButton();
	}

	@Then("^print error message for password field$")
	public void print_error_message_for_password_field() throws Throwable {
	    System.out.println("null value for password");
	    String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		//driver.close();
	}

	
/////////////////////////////////////////////
	
	@Given("^user selects  checkboxes$")
	public void user_selects_checkboxes() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		fact = new FormPageFactory(driver);
		driver.get("file:///C:/Users/hisachde/Desktop/Basicform.html");
	}
	
	@Then("^user clicks on checkboxes$")
	public void user_clicks_on_checkboxes() throws Throwable {
		//fact.setLang1(lang1);
	    fact.setButton();
	}
	
	@Then("^print error message for checkbox$")
	public void print_error_message_for_checkbox() throws Throwable {
		System.out.println("null value for password");
	    String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		//driver.close();
	}


}
