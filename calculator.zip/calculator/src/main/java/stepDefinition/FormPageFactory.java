package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FormPageFactory {

	@FindBy(how = How.NAME, using = "userName") 
	@CacheLookup
	WebElement userName;
	
	@FindBy(how = How.NAME, using = "city") 
	@CacheLookup
	WebElement city;
	
	@FindBy(how = How.NAME, using = "password") 
	@CacheLookup
	WebElement password;
	
	@FindBy(how = How.XPATH, using = "/html/body/center/form/input[11]") 
	@CacheLookup
	WebElement mobile;
	
	@FindBy(how = How.XPATH, using = "/html/body/center/form/input[12]") 
	@CacheLookup
	WebElement email;
	
	@FindBy(how = How.NAME, using = "mobile") 
	@CacheLookup
	WebElement alt_mobile;

	@FindBy(how = How.NAME, using = "lang1") 
	@CacheLookup
	WebElement lang1;
	
	@FindBy(how = How.NAME, using = "lang2") 
	@CacheLookup
	WebElement lang2;
	
	@FindBy(how = How.NAME, using = "lang3") 
	@CacheLookup
	WebElement lang3;
	
	
	public WebElement getLang1() {
		return lang1;
	}

	public void setLang1(String lang1) {
		this.lang1.sendKeys(lang1);
	}

	public WebElement getLang2() {
		return lang2;
	}

	public void setLang2(String lang2) {
		this.lang2.sendKeys(lang2);
	}

	public WebElement getLang3() {
		return lang3;
	}

	public void setLang3(String lang3) {
		this.lang3.sendKeys(lang3);
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getAlt_mobile() {
		return alt_mobile;
	}

	public void setAlt_mobile(String alt_mobile) {
		this.alt_mobile.sendKeys(alt_mobile);
	}
	
	public FormPageFactory() {
		// TODO Auto-generated constructor stub
	}

		
	WebDriver wd;
	public FormPageFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	@FindBy(xpath="/html/body/center/form/input[17]")
	@CacheLookup
	WebElement button;

	
	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

	public FormPageFactory(WebElement userName, WebElement city, WebElement password, WebElement mobile,
			WebElement email, WebElement alt_mobile, WebElement lang1, WebElement lang2, WebElement lang3, WebDriver wd,
			WebElement button) {
		super();
		this.userName = userName;
		this.city = city;
		this.password = password;
		this.mobile = mobile;
		this.email = email;
		this.alt_mobile = alt_mobile;
		this.lang1 = lang1;
		this.lang2 = lang2;
		this.lang3 = lang3;
		this.wd = wd;
		this.button = button;
	}

	@Override
	public String toString() {
		return "FormPageFactory [userName=" + userName + ", city=" + city + ", password=" + password + ", mobile="
				+ mobile + ", email=" + email + ", alt_mobile=" + alt_mobile + ", lang1=" + lang1 + ", lang2=" + lang2
				+ ", lang3=" + lang3 + ", wd=" + wd + ", button=" + button + "]";
	}
	
	
}
