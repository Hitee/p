package com.capg.cms.expection;

public class CustomerNotFound extends Exception
{

	
	
	
	
	
	
}
